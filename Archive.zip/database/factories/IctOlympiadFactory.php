<?php

use Faker\Generator as Faker;

$factory->define(App\IctOlympiad::class, function (Faker $faker) {
    return [
        //
    ];
});
