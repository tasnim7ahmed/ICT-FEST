<?php

use Faker\Generator as Faker;

$factory->define(App\business::class, function (Faker $faker) {
    return [
        //
    ];
});
