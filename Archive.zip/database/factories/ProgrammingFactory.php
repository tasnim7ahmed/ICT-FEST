<?php

use Faker\Generator as Faker;

$factory->define(App\Programming::class, function (Faker $faker) {
    return [
        //
    ];
});
