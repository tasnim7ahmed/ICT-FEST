<?php

use Faker\Generator as Faker;

$factory->define(App\Hackathon::class, function (Faker $faker) {
    return [
        //
    ];
});
