<?php

use Faker\Generator as Faker;

$factory->define(App\ProgrammingContest::class, function (Faker $faker) {
    return [
        //
    ];
});
