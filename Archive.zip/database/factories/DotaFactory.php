<?php

use Faker\Generator as Faker;

$factory->define(App\Dota::class, function (Faker $faker) {
    return [
        //
    ];
});
