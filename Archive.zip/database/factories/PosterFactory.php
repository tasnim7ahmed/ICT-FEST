<?php

use Faker\Generator as Faker;

$factory->define(App\Poster::class, function (Faker $faker) {
    return [
        //
    ];
});
