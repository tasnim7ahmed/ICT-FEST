<?php

use Faker\Generator as Faker;

$factory->define(App\Siege::class, function (Faker $faker) {
    return [
        //
    ];
});
