<?php $__env->startSection('body'); ?>
<div class="hero-wrap js-fullheight">
      <div class="overlay"></div>
      <div id="particles-js"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center" data-scrollax-parent="true">
          <div class="col-md-6 ftco-animate text-center" data-scrollax=" properties: { translateY: '70%' }">
            <p class="breadcrumbs" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">
            <h1 class="mb-3 bread" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">PAYMENT</h1>
          </div>
        </div>
      </div>
    </div>
    
    <section class="ftco-section">
      <div class="container">
        <div class="row justify-content-center mb-5 pb-5">
          <div class="col-md-6 text-center heading-section ftco-animate">
            <span class="subheading">Payment Section</span>
            <h2 class="mb-4">All payments' information and procedure will be revealed later !!!</h2>
            <p> </p>
          </div>
        </div>
      </div>
    </section>

    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front_end.master_front_end', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>