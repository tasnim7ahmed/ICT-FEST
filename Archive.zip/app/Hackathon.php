<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Hackathon extends Model
{
    protected $guarded = [];
}
