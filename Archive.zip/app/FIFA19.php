<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FIFA19 extends Model
{
	public $table = "f_i_f_a19s";
    protected $guarded = [];
}
