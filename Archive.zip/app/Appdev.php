<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Appdev extends Model
{
    protected $guarded = [];
}
