<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Dota extends Model
{
    protected $guarded = [];
}
