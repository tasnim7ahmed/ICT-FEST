<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProgrammingContest extends Model
{
    protected $guarded = [];
}
