<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Siege extends Model
{
    protected $guarded = [];
}
