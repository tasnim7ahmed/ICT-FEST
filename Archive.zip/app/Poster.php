<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\File;

class Poster extends Model
{
    protected $guarded = [];
}
