<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class business extends Model
{
    protected $guarded = [];
}
